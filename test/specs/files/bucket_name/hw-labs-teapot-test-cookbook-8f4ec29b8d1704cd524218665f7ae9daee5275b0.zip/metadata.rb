
name 'test-cookbook'
version '1.0.0'

maintainer 'Anthony Goddard'
maintainer_email 'anthony@hw-ops.com'
license 'Apache 2.0'
description ''
long_description ''

depends 'http-fail'
